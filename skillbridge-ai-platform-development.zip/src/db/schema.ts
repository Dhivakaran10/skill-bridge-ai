import { sql } from "drizzle-orm";
import { jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const learnerProfiles = pgTable("learner_profiles", {
  id: text("id").primaryKey(),
  name: text("name").notNull().default("Alex Morgan"),
  email: text("email").notNull().default(""),
  career: text("career").notNull().default("ai-engineer"),
  skills: jsonb("skills").$type<Record<string, number>>().notNull().default(sql`'{}'::jsonb`),
  completed: jsonb("completed").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});
