import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";
import { db } from "@/db";
import { learnerProfiles } from "@/db/schema";
import { CAREERS, courseActivityId, COURSES, DEFAULT_PROFILE, projectActivityId, SKILLS, type CareerId, type SkillId } from "@/lib/skill-data";

const validActivityIds = new Set([
  ...COURSES.map((course) => courseActivityId(course.id)),
  ...SKILLS.map((skill) => projectActivityId(skill.id)),
]);

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [profile] = await db.select().from(learnerProfiles).where(eq(learnerProfiles.id, DEFAULT_PROFILE.id)).limit(1);
    return Response.json({ ...(profile ?? DEFAULT_PROFILE), source: profile ? "database" : "demo" }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ ...DEFAULT_PROFILE, source: "local" }, { headers: { "Cache-Control": "no-store" } });
  }
}

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Please send a valid JSON profile." }, { status: 400 });
  }

  if (!body || typeof body !== "object") {
    return Response.json({ error: "Profile data is required." }, { status: 400 });
  }

  const input = body as Record<string, unknown>;
  const name = typeof input.name === "string" ? input.name.trim().slice(0, 80) : "";
  const email = typeof input.email === "string" ? input.email.trim().slice(0, 160) : "";
  const career = CAREERS.find((item) => item.id === input.career);

  if (!name) return Response.json({ error: "Please enter your name." }, { status: 400 });
  if (!career) return Response.json({ error: "Choose one of the available career paths." }, { status: 400 });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return Response.json({ error: "Enter a valid email address or leave it blank." }, { status: 400 });
  }

  const rawSkills = input.skills && typeof input.skills === "object" ? input.skills as Record<string, unknown> : {};
  const skills: Partial<Record<SkillId, number>> = {};
  for (const skill of SKILLS) {
    const value = rawSkills[skill.id];
    if (value === undefined) continue;
    if (typeof value !== "number" || !Number.isInteger(value) || value < 0 || value > 5) {
      return Response.json({ error: `Skill levels must be whole numbers from 0 to 5 (${skill.name}).` }, { status: 400 });
    }
    skills[skill.id] = value;
  }

  const rawCompleted = Array.isArray(input.completed) ? input.completed : [];
  if (rawCompleted.length > 100 || rawCompleted.some((item) => typeof item !== "string" || item.length > 100 || !validActivityIds.has(item))) {
    return Response.json({ error: "Progress data is not valid." }, { status: 400 });
  }
  const completed = [...new Set(rawCompleted as string[])];
  const values = {
    id: DEFAULT_PROFILE.id,
    name,
    email,
    career: career.id as CareerId,
    skills: { ...DEFAULT_PROFILE.skills, ...skills },
    completed,
    updatedAt: new Date(),
  };

  try {
    const [saved] = await db.insert(learnerProfiles).values(values).onConflictDoUpdate({
      target: learnerProfiles.id,
      set: { name: values.name, email: values.email, career: values.career, skills: values.skills, completed: values.completed, updatedAt: values.updatedAt },
    }).returning();
    return Response.json(saved, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "The database is unavailable right now. Your browser can still save this demo locally." }, { status: 503 });
  }
}
