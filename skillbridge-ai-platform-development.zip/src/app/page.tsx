import { SkillBridgeApp } from "@/components/skillbridge-app";

export default function HomePage() {
  return <SkillBridgeApp />;
}
