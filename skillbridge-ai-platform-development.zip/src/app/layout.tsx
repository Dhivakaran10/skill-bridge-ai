/* The App Router root layout loads this font for the entire application. */
/* eslint-disable @next/next/no-page-custom-font */
import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "SkillBridge AI — Learn with direction",
  description: "Understand your skill gaps, choose a career goal, and follow a personalized learning roadmap with free courses and practical projects.",
  applicationName: "SkillBridge AI",
  appleWebApp: { capable: true, title: "SkillBridge AI", statusBarStyle: "default" },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        <meta name="theme-color" content="#191a35" />
      </head>
      <body>{children}</body>
    </html>
  );
}
