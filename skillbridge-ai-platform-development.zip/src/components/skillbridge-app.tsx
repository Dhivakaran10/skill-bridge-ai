"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent } from "react";
import { Icon } from "@/components/icon";
import {
  analyzeCareer,
  CAREERS,
  courseActivityId,
  COURSES,
  DEFAULT_PROFILE,
  getCareer,
  getCoursesForCareer,
  getRoadmap,
  getSkill,
  MARKET_SOURCES,
  PROJECTS,
  projectActivityId,
  SKILLS,
  type CareerId,
  type LearnerProfile,
  type RoadmapActivity,
  type SkillGap,
  type SkillId,
} from "@/lib/skill-data";

type View = "overview" | "assessment" | "roadmap" | "courses" | "progress" | "about" | "profile";

const PROFILE_KEY = "skillbridge-profile-v1";
const LEVEL_LABELS = ["Not assessed", "New to it", "Beginner", "Developing", "Confident", "Advanced"];
const NAV = [
  { id: "overview", label: "Overview", icon: "grid" },
  { id: "assessment", label: "Skill assessment", icon: "target" },
  { id: "roadmap", label: "My roadmap", icon: "route" },
  { id: "courses", label: "Free courses", icon: "book" },
  { id: "progress", label: "Progress", icon: "chart" },
] as const;
const VIEW_TITLES: Record<View, string> = {
  overview: "Your dashboard",
  assessment: "Skill assessment",
  roadmap: "Your learning roadmap",
  courses: "Free learning resources",
  progress: "Learning progress",
  about: "The idea behind SkillBridge",
  profile: "Your learner profile",
};

function normalizeProfile(input: unknown): LearnerProfile | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as Record<string, unknown>;
  const rawSkills = raw.skills && typeof raw.skills === "object" ? raw.skills as Record<string, unknown> : {};
  const skills = { ...DEFAULT_PROFILE.skills };
  for (const skill of SKILLS) {
    const value = rawSkills[skill.id];
    if (typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 5) skills[skill.id] = value;
  }
  const career = CAREERS.find((item) => item.id === raw.career)?.id ?? DEFAULT_PROFILE.career;
  return {
    id: DEFAULT_PROFILE.id,
    name: typeof raw.name === "string" && raw.name.trim() ? raw.name.slice(0, 80) : DEFAULT_PROFILE.name,
    email: typeof raw.email === "string" ? raw.email.slice(0, 160) : DEFAULT_PROFILE.email,
    career: career as CareerId,
    skills,
    completed: Array.isArray(raw.completed) ? raw.completed.filter((item): item is string => typeof item === "string" && item.length <= 100).slice(0, 100) : [],
  };
}

function getInitials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? "").join("") || "S";
}

function ReadinessRing({ score, compact = false }: { score: number; compact?: boolean }) {
  const style = { "--ring-value": `${score * 3.6}deg` } as CSSProperties;
  return (
    <div className={`readiness-ring ${compact ? "readiness-ring-compact" : ""}`} style={style} role="img" aria-label={`Career readiness ${score} percent`}>
      <div className="readiness-ring-inner">
        <strong>{score}<span>%</span></strong>
        <small>readiness</small>
      </div>
    </div>
  );
}

function SkillBar({ row, compact = false }: { row: SkillGap; compact?: boolean }) {
  return (
    <div className={`skill-bar-row ${compact ? "skill-bar-compact" : ""}`}>
      <div className="skill-bar-label">
        <span className="skill-mini-icon" aria-hidden="true">{row.icon}</span>
        <span className="skill-bar-name">{row.name}</span>
        <span className="skill-level-text">{row.current}<span className="slash">/</span>{row.target}</span>
      </div>
      <div className="skill-bar-track" role="progressbar" aria-label={`${row.name} skill coverage`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={row.coverage}>
        <span className="skill-bar-fill" style={{ width: `${row.coverage}%` }} />
      </div>
      {!compact && <span className="skill-bar-caption">{row.gap === 0 ? "At target" : `${row.gap} ${row.gap === 1 ? "level" : "levels"} to build`}</span>}
    </div>
  );
}

function MetricCard({ icon, label, value, note, tone }: { icon: "target" | "layers" | "route" | "zap"; label: string; value: string; note: string; tone: string }) {
  return (
    <article className="metric-card">
      <div className={`metric-icon ${tone}`}><Icon name={icon} size={18} /></div>
      <p className="metric-label">{label}</p>
      <div className="metric-value-row"><strong>{value}</strong></div>
      <p className="metric-note">{note}</p>
    </article>
  );
}

function StatusPill({ complete }: { complete: boolean }) {
  return <span className={`status-pill ${complete ? "status-done" : "status-open"}`}><span className="status-dot" />{complete ? "Completed" : "Up next"}</span>;
}

function RoadmapCard({ activity, onToggle }: { activity: RoadmapActivity; onToggle: (id: string) => void }) {
  return (
    <article className={`roadmap-activity ${activity.complete ? "roadmap-activity-done" : ""}`}>
      <div className={`activity-kind-icon ${activity.kind === "course" ? "kind-course" : "kind-project"}`}>
        <Icon name={activity.kind === "course" ? "book" : "layers"} size={17} />
      </div>
      <div className="activity-copy">
        <div className="activity-meta"><span>{activity.kind === "course" ? "FREE RESOURCE" : "HANDS-ON PROJECT"}</span><span className="meta-dot">·</span><span>{getSkill(activity.skillId).name}</span></div>
        <h4>{activity.title}</h4>
        <p>{activity.detail}</p>
        <div className="activity-bottom">
          <span className="activity-duration"><Icon name="clock" size={14} />{activity.duration}</span>
          {activity.provider && <span className="activity-provider">{activity.provider}</span>}
        </div>
      </div>
      <div className="activity-actions">
        <StatusPill complete={activity.complete} />
        {activity.href && <a className="activity-link" href={activity.href} target="_blank" rel="noreferrer">Open resource <Icon name="external" size={14} /></a>}
        <button className={`complete-button ${activity.complete ? "complete-button-done" : ""}`} type="button" onClick={() => onToggle(activity.id)} aria-label={`${activity.complete ? "Undo completion of" : "Mark complete"} ${activity.title}`}>
          <Icon name={activity.complete ? "check" : "plus"} size={15} />{activity.complete ? "Done" : "Mark done"}
        </button>
      </div>
    </article>
  );
}

function CareerSelect({ value, onChange, compact = false }: { value: string; onChange: (id: CareerId) => void; compact?: boolean }) {
  const career = getCareer(value);
  return (
    <label className={`career-select ${compact ? "career-select-compact" : ""}`}>
      {!compact && <span className="field-label">CAREER GOAL</span>}
      <span className={`career-select-display career-tone-${career.color}`}>
        <span className="career-select-icon" aria-hidden="true">{career.icon}</span>
        <select aria-label="Choose your career goal" value={value} onChange={(event) => onChange(event.currentTarget.value as CareerId)}>
          {CAREERS.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}
        </select>
        <span className="select-chevron"><Icon name="chevron" size={14} /></span>
      </span>
    </label>
  );
}

export function SkillBridgeApp() {
  const [profile, setProfile] = useState<LearnerProfile>(DEFAULT_PROFILE);
  const [view, setView] = useState<View>("overview");
  const [loaded, setLoaded] = useState(false);
  const [saveState, setSaveState] = useState<"loading" | "saving" | "saved" | "local">("loading");
  const [toast, setToast] = useState("");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [courseFilter, setCourseFilter] = useState("all");
  const [showAllSkills, setShowAllSkills] = useState(false);
  const toastTimer = useRef<number | null>(null);
  const saveSequence = useRef(0);

  useEffect(() => {
    let cancelled = false;
    let localProfile: LearnerProfile | null = null;
    try {
      const saved = window.localStorage.getItem(PROFILE_KEY);
      if (saved) {
        localProfile = normalizeProfile(JSON.parse(saved));
      }
    } catch {
      localProfile = null;
    }
    const restore = async () => {
      try {
        const response = await fetch("/api/profile", { cache: "no-store" });
        const data = await response.json() as Record<string, unknown>;
        const remoteProfile = normalizeProfile(data);
        if (cancelled) return;
        if (data.source === "database" && remoteProfile) setProfile(remoteProfile);
        else if (localProfile) setProfile(localProfile);
        else if (remoteProfile) setProfile(remoteProfile);
        setSaveState(data.source === "local" ? "local" : data.source === "database" ? "saved" : "saving");
      } catch {
        if (cancelled) return;
        if (localProfile) setProfile(localProfile);
        setSaveState("local");
      }
      if (!cancelled) setLoaded(true);
    };
    void restore();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const sequence = ++saveSequence.current;
    try {
      window.localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    } catch {
      // The database is still attempted if browser storage is blocked.
    }
    const timer = window.setTimeout(() => {
      setSaveState("saving");
      void fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile),
      }).then((response) => {
        if (sequence === saveSequence.current) setSaveState(response.ok ? "saved" : "local");
      }).catch(() => {
        if (sequence === saveSequence.current) setSaveState("local");
      });
    }, 450);
    return () => window.clearTimeout(timer);
  }, [profile, loaded]);

  useEffect(() => {
    if (!toast) return;
    toastTimer.current = window.setTimeout(() => setToast(""), 3200);
    return () => { if (toastTimer.current) window.clearTimeout(toastTimer.current); };
  }, [toast]);

  const analysis = useMemo(() => analyzeCareer(profile.career, profile.skills), [profile.career, profile.skills]);
  const roadmap = useMemo(() => getRoadmap(profile.career, profile.skills, profile.completed), [profile.career, profile.skills, profile.completed]);
  const suggestedCourses = useMemo(() => getCoursesForCareer(profile.career, profile.skills, profile.completed), [profile.career, profile.skills, profile.completed]);
  const completedPlan = roadmap.filter((item) => item.complete).length;
  const planProgress = roadmap.length ? Math.round((completedPlan / roadmap.length) * 100) : 100;
  const currentCareer = getCareer(profile.career);
  const selectedSkills = showAllSkills ? analysis.rows : analysis.rows.slice(0, 4);

  const showToast = useCallback((message: string) => setToast(message), []);
  const updateProfile = useCallback((updates: Partial<LearnerProfile>) => {
    setProfile((current) => ({ ...current, ...updates }));
  }, []);
  const setCareer = useCallback((career: CareerId) => {
    setProfile((current) => ({ ...current, career }));
    setCourseFilter("all");
    setShowAllSkills(false);
  }, []);
  const setSkillLevel = useCallback((skillId: SkillId, value: number) => {
    setProfile((current) => ({ ...current, skills: { ...current.skills, [skillId]: value } }));
  }, []);
  const toggleActivity = useCallback((id: string) => {
    setProfile((current) => {
      const alreadyDone = current.completed.includes(id);
      const completed = alreadyDone ? current.completed.filter((item) => item !== id) : [...current.completed, id].slice(-100);
      return { ...current, completed };
    });
    showToast(profile.completed.includes(id) ? "Activity moved back to your plan." : "Nice work — your learning progress is updated.");
  }, [profile.completed, showToast]);
  const navigate = useCallback((next: View) => {
    setView(next);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const exportPlan = useCallback(() => {
    const lines = [
      "SKILLBRIDGE AI · PERSONAL CAREER ROADMAP",
      `Learner: ${profile.name}`,
      `Career goal: ${currentCareer.title}`,
      `Career readiness: ${analysis.score}% (skill coverage estimate, not a hiring prediction)`,
      "",
      "SKILL GAPS",
      ...analysis.rows.map((row) => `- ${row.name}: ${row.current}/5 current · ${row.target}/5 target · ${row.gap} level${row.gap === 1 ? "" : "s"} to build`),
      "",
      "ROADMAP",
      ...(roadmap.length ? roadmap.map((item, index) => `${index + 1}. [${item.complete ? "x" : " "}] ${item.title} — ${item.detail}${item.href ? ` (${item.href})` : ""}`) : ["All assessed career skills are at their current target. Reassess or choose another career goal." ]),
      "",
      "Recommendations are rule-based and use the learner's self-assessed skill levels.",
    ];
    const file = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(file);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "skillbridge-career-roadmap.txt";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    showToast("Your roadmap has been downloaded.");
  }, [analysis, currentCareer.title, profile.name, roadmap, showToast]);

  const handleProfileSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    navigate("overview");
    showToast("Profile saved. Your recommendations are up to date.");
  };

  const resetDemo = () => {
    if (!window.confirm("Reset the shared demo learner to the sample assessment?")) return;
    setProfile({ ...DEFAULT_PROFILE, skills: { ...DEFAULT_PROFILE.skills }, completed: [] });
    try { window.localStorage.removeItem(PROFILE_KEY); } catch { /* storage may be blocked */ }
    showToast("Sample demo profile restored.");
  };

  const courseList = suggestedCourses.filter((course) => courseFilter === "all" || course.skillId === courseFilter);
  const completedItems = [
    ...COURSES.filter((course) => profile.completed.includes(courseActivityId(course.id))).map((course) => ({ id: courseActivityId(course.id), title: course.title, detail: getSkill(course.skillId).name, kind: "Course" })),
    ...SKILLS.filter((skill) => profile.completed.includes(projectActivityId(skill.id))).map((skill) => ({ id: projectActivityId(skill.id), title: PROJECTS[skill.id].title, detail: skill.name, kind: "Project" })),
  ];

  const renderOverview = () => (
    <>
      <div className="page-intro-row">
        <div>
          <p className="eyebrow"><span className="eyebrow-dot" /> YOUR PERSONAL LEARNING SPACE</p>
          <h2>Good things grow <span>one skill at a time.</span></h2>
          <p className="intro-copy">A clear view of where you are, what your goal asks for, and what to try next.</p>
        </div>
        <button type="button" className="button button-quiet" onClick={() => navigate("profile")}><Icon name="user" size={16} /> Edit profile</button>
      </div>

      <section className="welcome-card" aria-labelledby="welcome-title">
        <div className="welcome-orb welcome-orb-one" /><div className="welcome-orb welcome-orb-two" />
        <div className="welcome-copy">
          <span className="welcome-kicker"><Icon name="spark" size={14} /> YOUR CAREER, MADE CLEARER</span>
          <h3 id="welcome-title">Build toward <span>{currentCareer.title}.</span></h3>
          <p>{currentCareer.summary} Start with your strengths and turn the biggest gaps into small, practical next steps.</p>
          <div className="welcome-actions">
            <button type="button" className="button button-lilac" onClick={() => navigate("roadmap")}>View my roadmap <Icon name="arrow" size={16} /></button>
            <button type="button" className="button button-glass" onClick={exportPlan}><Icon name="download" size={15} /> Download plan</button>
          </div>
        </div>
        <div className="welcome-score">
          <ReadinessRing score={analysis.score} />
          <div className="welcome-score-copy"><strong>{analysis.score >= 70 ? "Good momentum" : analysis.score >= 40 ? "Foundations in progress" : "A fresh starting point"}</strong><span>Career readiness</span><small>Based on your current skills</small></div>
        </div>
        <div className="welcome-footer"><span><Icon name="shield" size={14} /> A skill-coverage snapshot, not a hiring prediction</span><CareerSelect compact value={profile.career} onChange={setCareer} /></div>
      </section>

      <div className="metrics-grid">
        <MetricCard icon="target" label="Career readiness" value={`${analysis.score}%`} note="Skill coverage against your goal" tone="metric-violet" />
        <MetricCard icon="layers" label="Skills to strengthen" value={`${analysis.missing.length}`} note={`Across ${analysis.rows.length} role requirements`} tone="metric-blue" />
        <MetricCard icon="route" label="Roadmap complete" value={`${planProgress}%`} note={`${completedPlan} of ${roadmap.length} activities done`} tone="metric-green" />
        <MetricCard icon="zap" label="Best next step" value={analysis.missing[0]?.name ?? "Reassess"} note={analysis.missing[0] ? `${analysis.missing[0].gap} level${analysis.missing[0].gap === 1 ? "" : "s"} below target` : "Your current skills meet this target"} tone="metric-orange" />
      </div>

      <div className="overview-columns">
        <section className="panel skill-snapshot" aria-labelledby="snapshot-title">
          <div className="panel-heading">
            <div><p className="eyebrow">YOUR BASELINE</p><h3 id="snapshot-title">Skill coverage</h3><p className="panel-subtitle">Current level compared with the target for {currentCareer.title}.</p></div>
            <button type="button" className="text-link" onClick={() => navigate("assessment")}>Update skills <Icon name="arrow" size={15} /></button>
          </div>
          <div className="snapshot-bars">
            {selectedSkills.map((row) => <SkillBar key={row.id} row={row} compact />)}
          </div>
          {analysis.rows.length > 4 && <button className="show-more-button" type="button" onClick={() => setShowAllSkills((value) => !value)}>{showAllSkills ? "Show fewer" : `Show all ${analysis.rows.length} skills`}<Icon name="chevron" size={14} /></button>}
          <div className="snapshot-legend"><span><i className="legend-dot legend-current" />Your current coverage</span><span><i className="legend-dot legend-target" />Role target: {currentCareer.title}</span></div>
        </section>

        <section className="panel next-steps-panel" aria-labelledby="steps-title">
          <div className="panel-heading"><div><p className="eyebrow">A SMALL, CLEAR NEXT STEP</p><h3 id="steps-title">Start here</h3></div><span className="step-count">{Math.min(roadmap.length, 3)} PICKS</span></div>
          {roadmap.length === 0 ? <div className="empty-small"><span className="empty-icon"><Icon name="check" size={20} /></span><strong>You’re at today’s targets.</strong><p>Reassess your skills as you learn, or explore another role.</p><button type="button" className="text-link" onClick={() => navigate("assessment")}>Review assessment <Icon name="arrow" size={15} /></button></div> : (
            <div className="next-step-list">
              {roadmap.filter((item) => !item.complete).slice(0, 3).map((item, index) => (
                <div className="next-step-item" key={item.id}>
                  <span className={`step-index ${index === 0 ? "step-index-active" : ""}`}>{String(index + 1).padStart(2, "0")}</span>
                  <div className="next-step-copy"><span>{item.kind === "course" ? "LEARN" : "MAKE"} · {getSkill(item.skillId).name}</span><strong>{item.title}</strong></div>
                  <button type="button" className="icon-action" onClick={() => item.href ? window.open(item.href, "_blank", "noopener,noreferrer") : navigate("roadmap")} aria-label={item.href ? `Open ${item.title}` : `View ${item.title} project`}><Icon name="arrow" size={16} /></button>
                </div>
              ))}
              {roadmap.filter((item) => !item.complete).length === 0 && <p className="all-done-note"><Icon name="check" size={15} /> Your current roadmap is complete. Great work.</p>}
            </div>
          )}
          <button type="button" className="panel-bottom-link" onClick={() => navigate("roadmap")}>See the full roadmap <Icon name="arrow" size={15} /></button>
        </section>
      </div>

      <div className="overview-columns overview-columns-bottom">
        <section className="panel course-preview-panel" aria-labelledby="course-preview-title">
          <div className="panel-heading"><div><p className="eyebrow">OPEN LEARNING, NO PAYWALLS</p><h3 id="course-preview-title">Picked for your next gaps</h3><p className="panel-subtitle">Matched to your assessment · recommendations use transparent rules.</p></div><button type="button" className="text-link" onClick={() => navigate("courses")}>All resources <Icon name="arrow" size={15} /></button></div>
          {suggestedCourses.slice(0, 3).length ? <div className="course-preview-list">{suggestedCourses.slice(0, 3).map((course) => {
            const skill = getSkill(course.skillId);
            const gap = analysis.rows.find((row) => row.id === course.skillId)?.gap ?? 0;
            return <article className="course-preview" key={course.id}><div className="course-cover"><span>{skill.icon}</span><small>{course.format}</small></div><div className="course-preview-copy"><span className="course-skill">{skill.name} · {gap} levels to target</span><h4>{course.title}</h4><p>{course.provider} <span>·</span> {course.duration}</p></div><a className="icon-action" href={course.href} target="_blank" rel="noreferrer" aria-label={`Open ${course.title}`}><Icon name="external" size={16} /></a></article>;
          })}</div> : <div className="empty-small"><strong>All required skills are at target.</strong><p>Reassess your skill levels to refresh your suggestions.</p></div>}
        </section>
        <section className="panel readiness-panel" aria-labelledby="readiness-panel-title">
          <div className="panel-heading"><div><p className="eyebrow">THE MATH, IN THE OPEN</p><h3 id="readiness-panel-title">How readiness works</h3></div><span className="info-tag">NO BLACK BOX</span></div>
          <p className="readiness-explainer">For each role skill, we compare your self-rating with its target. The dashboard averages those coverage percentages.</p>
          <div className="formula-card"><span>MIN(current ÷ target, 1)</span><strong>→</strong><span>average × 100</span></div>
          <p className="formula-footnote">If Python is 2/5 for an AI Engineer target of 5, Python contributes 40% coverage. Your overall score is the average across the role’s required skills.</p>
          <button type="button" className="text-link" onClick={() => navigate("about")}>Why this matters <Icon name="arrow" size={15} /></button>
        </section>
      </div>
    </>
  );

  const renderAssessment = () => (
    <>
      <div className="page-intro-row page-intro-assessment">
        <div><p className="eyebrow"><span className="eyebrow-dot" /> STEP 01 · YOUR STARTING POINT</p><h2>What can you do <span>today?</span></h2><p className="intro-copy">Be honest, not perfect. This is a self-assessment, not a test — you can change any level as you learn.</p></div>
        <div className="assessment-score-chip"><ReadinessRing score={analysis.score} compact /><span><strong>{analysis.score}%</strong><small>career readiness</small></span></div>
      </div>
      <div className="assessment-layout">
        <section className="panel assessment-panel" aria-labelledby="assessment-list-title">
          <div className="assessment-toolbar"><div><p className="eyebrow">ROLE REQUIREMENTS</p><h3 id="assessment-list-title">Rate your skills</h3><p className="panel-subtitle">Targets are example proficiency levels for this prototype, not formal hiring standards.</p></div><CareerSelect compact value={profile.career} onChange={setCareer} /></div>
          <div className="skill-assessment-list">
            {analysis.rows.map((row) => {
              const rangeStyle = { "--range-fill": `${row.current * 20}%` } as CSSProperties;
              return <article className="skill-assessment-card" key={row.id}>
                <div className="assessment-card-top"><div className="skill-ident"><span className="skill-icon-box">{row.icon}</span><div><h4>{row.name}</h4><p>{row.description}</p></div></div><div className={`level-badge ${row.current >= row.target ? "level-badge-ready" : ""}`}><strong>{row.current}<span>/5</span></strong><small>{LEVEL_LABELS[row.current]}</small></div></div>
                <label className="range-label" htmlFor={`skill-${row.id}`}>Your current level <span>Target for {currentCareer.title}: <strong>{row.target}/5</strong></span></label>
                <input id={`skill-${row.id}`} className="skill-range" type="range" min="0" max="5" step="1" value={row.current} style={rangeStyle} aria-label={`${row.name} proficiency, ${row.current} out of 5`} onChange={(event) => setSkillLevel(row.id, Number(event.currentTarget.value))} />
                <div className="range-ticks" aria-hidden="true">{LEVEL_LABELS.map((label, index) => <span key={index} className={index <= row.current ? "tick-active" : ""}>{index}</span>)}</div>
                <div className="assessment-result-line"><span>{row.current >= row.target ? <><Icon name="check" size={14} /> At or above this role’s example target</> : <><Icon name="target" size={14} /> {row.gap} {row.gap === 1 ? "level" : "levels"} between your current skill and target</>}</span><strong>{row.coverage}% coverage</strong></div>
              </article>;
            })}
          </div>
          <div className="assessment-panel-footer"><span><Icon name="shield" size={15} /> Your profile is saved to this demo workspace.</span><button type="button" className="button button-primary" onClick={() => { navigate("roadmap"); showToast("Your roadmap has been refreshed using this assessment."); }}>Build my roadmap <Icon name="arrow" size={16} /></button></div>
        </section>
        <aside className="assessment-aside">
          <div className="panel score-explainer-card"><div className="score-explainer-top"><span className="eyebrow">LIVE CAREER READINESS</span><ReadinessRing score={analysis.score} compact /></div><h3>{analysis.missing.length ? `${analysis.missing.length} skills to strengthen` : "You’re at the target"}</h3><p>Move a slider and this score, your priorities, and your learning plan update together.</p><div className="score-divider" /><div className="score-stat-row"><span>Skill coverage</span><strong>{analysis.coverage}%</strong></div><div className="score-stat-row"><span>Overall skill gap</span><strong>{analysis.gapPercent}%</strong></div><div className="score-stat-row"><span>Required skills</span><strong>{analysis.rows.length}</strong></div></div>
          <div className="privacy-note"><span className="privacy-icon"><Icon name="shield" size={17} /></span><div><strong>A useful mirror, not a verdict.</strong><p>This score describes your self-rated skills against example targets. It does not predict whether you will get a job.</p></div></div>
        </aside>
      </div>
    </>
  );

  const renderRoadmap = () => (
    <>
      <div className="page-intro-row">
        <div><p className="eyebrow"><span className="eyebrow-dot" /> ADAPTED TO YOUR ASSESSMENT</p><h2>A path built around <span>your gaps.</span></h2><p className="intro-copy">We sort the skills furthest from your chosen career target first. Learn a concept, then practice it in a small project.</p></div>
        <button type="button" className="button button-quiet" onClick={exportPlan}><Icon name="download" size={16} /> Download plan</button>
      </div>
      <section className="roadmap-summary-card"><div className="roadmap-summary-icon"><Icon name="route" size={21} /></div><div className="roadmap-summary-copy"><span>YOUR CURRENT GOAL</span><strong>{currentCareer.title}</strong><p>{currentCareer.summary}</p></div><div className="roadmap-summary-progress"><div className="summary-progress-top"><span>Plan progress</span><strong>{planProgress}%</strong></div><div className="progress-track"><span style={{ width: `${planProgress}%` }} /></div><small>{completedPlan} of {roadmap.length} activities completed</small></div><CareerSelect compact value={profile.career} onChange={setCareer} /></section>
      <div className="roadmap-section-heading"><div><p className="eyebrow">PRIORITIZED, NOT PRESCRIPTIVE</p><h3>Your next steps</h3></div><span className="rule-engine-tag"><Icon name="spark" size={14} /> Rule-based · explainable</span></div>
      {analysis.missing.length === 0 ? <div className="panel all-clear-panel"><div className="all-clear-icon"><Icon name="check" size={23} /></div><h3>Every assessed skill meets its example target.</h3><p>Nice work. Update your self-assessment as you learn, explore free courses, or choose another career path to compare.</p><div className="all-clear-actions"><button className="button button-primary" type="button" onClick={() => navigate("assessment")}>Reassess skills <Icon name="refresh" size={15} /></button><button className="button button-quiet" type="button" onClick={() => navigate("courses")}>Browse resources <Icon name="arrow" size={15} /></button></div></div> : <div className="roadmap-groups">{analysis.missing.map((row, index) => {
        const skillActivities = roadmap.filter((activity) => activity.skillId === row.id);
        return <section className="roadmap-group" key={row.id}>
          <div className="roadmap-group-marker"><span>{String(index + 1).padStart(2, "0")}</span><i /></div>
          <div className="roadmap-group-body"><div className="roadmap-group-title"><div><span className="roadmap-group-kicker">FOCUS AREA {String(index + 1).padStart(2, "0")}</span><h3>{row.name}</h3><p>{row.gap} skill {row.gap === 1 ? "level" : "levels"} to target · {row.coverage}% covered</p></div><span className="focus-skill-icon">{row.icon}</span></div>
            <div className="roadmap-activities">{skillActivities.map((activity) => <RoadmapCard key={activity.id} activity={activity} onToggle={toggleActivity} />)}</div>
          </div>
        </section>;
      })}</div>}
      <div className="roadmap-footnote"><Icon name="spark" size={15} /><p><strong>How the order is picked:</strong> skills are sorted by the share of the target still missing. Each gap gets one free learning resource and a portfolio-ready practice idea. Reassess to change the plan.</p></div>
    </>
  );

  const renderCourses = () => {
    const courseSkills = [...new Set(suggestedCourses.map((course) => course.skillId))];
    return <>
      <div className="page-intro-row"><div><p className="eyebrow"><span className="eyebrow-dot" /> RESOURCES FOR YOUR NEXT STEP</p><h2>Good learning should be <span>within reach.</span></h2><p className="intro-copy">Hand-picked free resources that match the open skill gaps in your {currentCareer.title} plan.</p></div><span className="free-stamp"><Icon name="check" size={15} /> FREE TO ACCESS</span></div>
      <section className="course-callout"><div className="callout-icon"><Icon name="spark" size={20} /></div><div><strong>Personalized, without pretending to be magic.</strong><p>These are rule-based matches: we rank role skills with the largest remaining gap, then show free resources for those skills. No AI model or paid API is being claimed.</p></div><span className="rule-engine-tag">EXPLAINABLE MATCH</span></section>
      <div className="course-toolbar"><div><h3>Recommended for your gaps <span>{courseList.length}</span></h3><p>Career goal: {currentCareer.title}</p></div><label className="filter-select"><span>Filter</span><select value={courseFilter} onChange={(event) => setCourseFilter(event.currentTarget.value)}><option value="all">All priority skills</option>{courseSkills.map((id) => <option key={id} value={id}>{getSkill(id).name}</option>)}</select><Icon name="chevron" size={14} /></label></div>
      {courseList.length ? <div className="course-grid">{courseList.map((course, index) => {
        const skill = getSkill(course.skillId);
        const gap = analysis.rows.find((row) => row.id === course.skillId)?.gap ?? 0;
        return <article className="course-card" key={course.id}><div className={`course-card-top tone-${index % 4}`}><span className="course-art-icon">{skill.icon}</span><span className="course-art-type">{course.format}</span><span className="course-art-orb" /></div><div className="course-card-content"><div className="course-card-meta"><span className="course-skill-tag">{skill.name}</span><span className="gap-tag">{gap} level{gap === 1 ? "" : "s"} to target</span></div><h3>{course.title}</h3><p className="course-provider">{course.provider}</p><p className="course-detail">{course.detail}</p><div className="course-card-footer"><span><Icon name="clock" size={14} />{course.duration}</span><span className="free-dot"><i /> Free</span></div><div className="course-card-actions"><a className="button button-primary button-full" href={course.href} target="_blank" rel="noreferrer">Start learning <Icon name="external" size={15} /></a><button className="course-done-button" type="button" onClick={() => toggleActivity(courseActivityId(course.id))}><Icon name="check" size={15} /> Mark complete</button></div></div></article>;
      })}</div> : <div className="panel empty-state"><span className="empty-state-icon"><Icon name="check" size={24} /></span><h3>{suggestedCourses.length ? "No resources match that filter." : "No open course recommendations."}</h3><p>{suggestedCourses.length ? "Choose a different skill or clear the filter." : "You’ve marked the available recommendations complete, or your assessment has no gaps. Reassess your skills to update your plan."}</p><button type="button" className="button button-primary" onClick={() => { setCourseFilter("all"); navigate("assessment"); }}>Review my assessment <Icon name="arrow" size={15} /></button></div>}
      <p className="resource-disclaimer"><Icon name="shield" size={14} /> Resources are hosted by their publishers. Availability, enrolment rules, and optional certificates may change; check each provider’s page.</p>
    </>;
  };

  const renderProgress = () => (
    <>
      <div className="page-intro-row"><div><p className="eyebrow"><span className="eyebrow-dot" /> YOUR LEARNING, MADE VISIBLE</p><h2>Every small step <span>counts.</span></h2><p className="intro-copy">Track what you’ve tried, see where the plan is moving, and adjust your assessment as confidence grows.</p></div><button type="button" className="button button-quiet" onClick={() => navigate("assessment")}><Icon name="target" size={16} /> Reassess skills</button></div>
      <div className="progress-overview-grid"><section className="panel progress-score-card"><div className="progress-ring-wrap"><ReadinessRing score={planProgress} /></div><div><span className="eyebrow">ROADMAP PROGRESS</span><h3>{planProgress}% <span>complete</span></h3><p>{completedPlan} of {roadmap.length} activities on your {currentCareer.title} plan are done.</p><button type="button" className="text-link" onClick={() => navigate("roadmap")}>Open roadmap <Icon name="arrow" size={15} /></button></div></section><article className="panel progress-stat-card"><span className="metric-icon metric-violet"><Icon name="check" size={18} /></span><p className="metric-label">Activities completed</p><strong>{profile.completed.length}</strong><p className="metric-note">Saved in your learner profile</p></article><article className="panel progress-stat-card"><span className="metric-icon metric-blue"><Icon name="target" size={18} /></span><p className="metric-label">Current career readiness</p><strong>{analysis.score}%</strong><p className="metric-note">Updates when you reassess a skill</p></article></div>
      <div className="progress-columns"><section className="panel progress-skill-panel"><div className="panel-heading"><div><p className="eyebrow">ASSESSMENT SNAPSHOT</p><h3>Skills moving toward your goal</h3><p className="panel-subtitle">Your current level is self-reported. Update it after practice, not just after finishing a video.</p></div><span className="info-tag">{currentCareer.title}</span></div><div className="progress-skill-list">{analysis.rows.map((row) => <div className="progress-skill-item" key={row.id}><SkillBar row={row} compact /><span className={`gap-status ${row.gap === 0 ? "gap-status-done" : ""}`}>{row.gap === 0 ? "At target" : `${row.gap} to go`}</span></div>)}</div><div className="reassess-tip"><Icon name="spark" size={16} /><span>Finished practicing? Reassess your skill level to update your career-readiness score.</span><button type="button" className="text-link" onClick={() => navigate("assessment")}>Update <Icon name="arrow" size={14} /></button></div></section>
        <section className="panel completed-panel"><div className="panel-heading"><div><p className="eyebrow">YOUR HISTORY</p><h3>Completed activities</h3></div><span className="step-count">{completedItems.length} DONE</span></div>{completedItems.length ? <div className="completed-list">{completedItems.slice().reverse().map((item) => <div className="completed-item" key={item.id}><span className="completed-check"><Icon name="check" size={14} /></span><div><strong>{item.title}</strong><small>{item.kind} · {item.detail}</small></div><button type="button" className="undo-link" onClick={() => toggleActivity(item.id)}>Undo</button></div>)}</div> : <div className="empty-small completed-empty"><span className="empty-icon"><Icon name="layers" size={18} /></span><strong>Your first completed activity goes here.</strong><p>Start a free course or finish a project step on your roadmap.</p><button type="button" className="text-link" onClick={() => navigate("roadmap")}>See my next step <Icon name="arrow" size={15} /></button></div>}</section></div>
      <section className="panel momentum-panel"><div className="momentum-copy"><span className="eyebrow">A NOTE ON THE NUMBERS</span><h3>Progress is more than a percentage.</h3><p>We count activities you mark complete, but we do not silently increase your proficiency score. You stay in control of the self-assessment — so the readiness score remains honest and explainable.</p></div><div className="momentum-graphic" aria-hidden="true"><span className="momentum-node node-one"><Icon name="book" size={17} /></span><span className="momentum-node node-two"><Icon name="layers" size={17} /></span><span className="momentum-node node-three"><Icon name="target" size={17} /></span><i className="momentum-path" /></div></section>
    </>
  );

  const renderProfile = () => (
    <>
      <div className="page-intro-row"><div><p className="eyebrow"><span className="eyebrow-dot" /> YOUR DEMO LEARNER</p><h2>Make this space <span>yours.</span></h2><p className="intro-copy">Choose a goal and keep your skill baseline up to date. Your roadmap changes with you.</p></div><span className={`save-pill ${saveState}`}><i />{saveState === "saved" ? "Saved to database" : saveState === "local" ? "Saved in this browser" : saveState === "saving" ? "Saving changes" : "Loading profile"}</span></div>
      <form className="profile-layout" onSubmit={handleProfileSubmit}>
        <section className="panel profile-form-panel"><div className="panel-heading"><div><p className="eyebrow">ABOUT YOU</p><h3>Learner profile</h3></div><span className="profile-avatar-large">{getInitials(profile.name)}</span></div><label className="form-field"><span className="field-label">YOUR NAME</span><input required minLength={2} maxLength={80} value={profile.name} onChange={(event) => updateProfile({ name: event.currentTarget.value })} placeholder="e.g. Alex Morgan" /></label><label className="form-field"><span className="field-label">EMAIL ADDRESS <span className="optional-label">OPTIONAL</span></span><span className="input-with-icon"><Icon name="mail" size={17} /><input type="email" maxLength={160} value={profile.email} onChange={(event) => updateProfile({ email: event.currentTarget.value })} placeholder="you@example.com" /></span></label><div className="form-hint"><Icon name="shield" size={15} /><span>This MVP is a shared demo learner, not a real sign-in service. Don’t enter sensitive information. Your profile is saved to the demo database when available and to this browser as a fallback.</span></div></section>
        <section className="panel career-form-panel"><div className="panel-heading"><div><p className="eyebrow">WHERE YOU WANT TO GO</p><h3>Choose a career goal</h3><p className="panel-subtitle">Compare your current skills with one of these five starting profiles.</p></div></div><div className="career-choice-grid">{CAREERS.map((career) => <button type="button" key={career.id} aria-pressed={profile.career === career.id} className={`career-choice career-choice-${career.color} ${profile.career === career.id ? "career-choice-selected" : ""}`} onClick={() => setCareer(career.id)}><span className="career-choice-icon">{career.icon}</span><span className="career-choice-copy"><strong>{career.title}</strong><small>{career.category}</small></span><span className="career-choice-check"><Icon name="check" size={14} /></span></button>)}</div><p className="career-choice-summary"><Icon name="spark" size={15} />{currentCareer.summary}</p></section>
        <div className="profile-form-actions"><button type="button" className="button button-quiet" onClick={resetDemo}><Icon name="refresh" size={15} /> Reset demo data</button><button type="submit" className="button button-primary">Save profile <Icon name="arrow" size={16} /></button></div>
      </form>
    </>
  );

  const renderAbout = () => (
    <>
      <div className="page-intro-row about-intro"><div><p className="eyebrow"><span className="eyebrow-dot" /> THE WHY, THE HOW, THE DEMO</p><h2>Learning should start <span>with you.</span></h2><p className="intro-copy">SkillBridge AI is a student-first prototype for making career preparation feel less like guesswork.</p></div><span className="about-badge"><Icon name="spark" size={16} /> BUILT FOR A HACKATHON DEMO</span></div>
      <section className="problem-hero"><div className="problem-hero-icon"><Icon name="layers" size={24} /></div><div><span className="eyebrow">THE PROBLEM</span><h3>One course path does not fit every starting point.</h3><p>Students can have the same career goal but very different skills, interests, and time. A catalogue of courses alone does not tell someone what to learn first — or whether their practice is closing the right gap.</p></div></section>
      <div className="research-heading"><div><p className="eyebrow">MARKET SIGNALS · SOURCED</p><h3>Why a skill-first approach matters</h3><p>Published findings below describe labour-market context. They do not prove that this prototype improves hiring outcomes.</p></div><span className="citation-tag">3 CITED REPORTS</span></div>
      <div className="research-grid">{MARKET_SOURCES.map((source, index) => <article className="panel research-card" key={source.title}><div className="research-card-top"><span className={`research-index research-index-${index}`}>{String(index + 1).padStart(2, "0")}</span><span className="research-date">{source.date}</span></div><p className="research-publisher">{source.publisher}</p><h4>{source.title}</h4><p className="research-finding">{source.finding}</p><a className="text-link" href={source.href} target="_blank" rel="noreferrer">Read the source <Icon name="external" size={14} /></a></article>)}</div>
      <section className="panel causes-panel"><div className="panel-heading"><div><p className="eyebrow">ROOT CAUSES WE’RE DESIGNING AROUND</p><h3>Why the gap can be hard to see</h3><p className="panel-subtitle">These are product hypotheses to test with learners and educators, not claims that every student experiences the same thing.</p></div></div><div className="causes-grid"><article><span>01</span><h4>Starting points are different</h4><p>A common curriculum may not account for prior projects, self-study, or uneven confidence across skills.</p></article><article><span>02</span><h4>Career requirements feel abstract</h4><p>Role titles are easy to choose; the specific skills and proficiency needed are harder to turn into a plan.</p></article><article><span>03</span><h4>Content and guidance are separate</h4><p>Learning resources are plentiful, but learners still need to decide which resource fits the next gap.</p></article><article><span>04</span><h4>Progress needs a feedback loop</h4><p>Completing content matters, but a learner should revisit their skills and see what the next useful step is.</p></article></div></section>
      <section className="panel competitors-panel"><div className="panel-heading"><div><p className="eyebrow">THE LANDSCAPE</p><h3>Learning platforms do a lot. Here’s our narrow bet.</h3><p className="panel-subtitle">A feature-level comparison based on public product positioning — not an exhaustive audit.</p></div></div><div className="competitor-table-wrap"><table className="competitor-table"><thead><tr><th>Approach</th><th>What it does well</th><th>SkillBridge’s focus</th></tr></thead><tbody><tr><td><a href="https://www.coursera.org/" target="_blank" rel="noreferrer">Course marketplaces <Icon name="external" size={12} /></a></td><td>Broad catalogues and structured learning from institutions and partners.</td><td>Start with the learner’s own skill baseline, then point to the next relevant open resource.</td></tr><tr><td><a href="https://www.linkedin.com/learning/" target="_blank" rel="noreferrer">Career learning libraries <Icon name="external" size={12} /></a></td><td>Career-oriented content and guided learning experiences.</td><td>Make the skill-by-skill comparison visible and editable, not a hidden score.</td></tr><tr><td><a href="https://www.kaggle.com/learn" target="_blank" rel="noreferrer">Kaggle Learn <Icon name="external" size={12} /></a></td><td>Short, practical lessons for data and programming topics.</td><td>Connect learning resources with a multi-skill role roadmap and a practice project.</td></tr><tr className="skillbridge-row"><td>SkillBridge AI</td><td>Role-specific self-assessment and transparent gap calculation.</td><td>Adaptive next steps, free resource links, project practice, and learner-owned reassessment.</td></tr></tbody></table></div><p className="comparison-footnote">Products evolve and may offer features beyond this summary. The differentiation is a prototype hypothesis: an inspectable gap-to-action loop, not a claim that competitors never personalize.</p></section>
      <div className="impact-heading"><div><p className="eyebrow">WHO BENEFITS</p><h3>Useful at more than one scale</h3></div></div>
      <div className="impact-grid"><article className="impact-card impact-student"><span className="impact-card-icon"><Icon name="user" size={19} /></span><span className="impact-label">FOR STUDENTS</span><h4>Replace “where do I start?” with a next step.</h4><ul><li>See strengths and missing skills for a chosen role.</li><li>Find free learning and practice ideas in one place.</li><li>Prepare a visible portfolio trail for internship conversations.</li></ul></article><article className="impact-card impact-campus"><span className="impact-card-icon"><Icon name="cap" size={19} /></span><span className="impact-label">FOR UNIVERSITIES</span><h4>Turn student insight into better support.</h4><ul><li>Spot repeated gaps across a cohort with consent and aggregated data.</li><li>Connect workshops and curricula to emerging skill needs.</li><li>Track development over time without ranking students by a single score.</li></ul></article><article className="impact-card impact-team"><span className="impact-card-icon"><Icon name="layers" size={19} /></span><span className="impact-label">FOR ORGANIZATIONS</span><h4>Make workforce learning more targeted.</h4><ul><li>Map role expectations to employee self-assessments.</li><li>Suggest relevant development instead of one generic course list.</li><li>Support planning while keeping managers in the loop.</li></ul></article></div>
      <section className="presentation-section"><div className="presentation-heading"><div><p className="eyebrow">HACKATHON READY</p><h3>Your presentation kit</h3><p>Simple notes to explain the product honestly and demonstrate the full flow.</p></div><span className="presentation-time"><Icon name="clock" size={15} /> 8-HOUR BUILD PLAN</span></div>
        <div className="presentation-grid"><article className="panel pitch-card"><span className="presentation-label">01 · PROJECT INTRO + 2-MINUTE PITCH</span><h4>SkillBridge AI makes the first step in career learning clearer.</h4><p>Students are often shown a long list of courses without a clear picture of what they already know or what their target role expects. SkillBridge starts with a simple skill self-assessment, compares it with a transparent role profile, and shows the gaps that matter most. It then turns those gaps into a prioritized roadmap with free resources and practical projects. Learners can mark work complete and reassess as they progress. The readiness score is an explainable coverage calculation — not a prediction of getting hired. This MVP uses rule-based recommendations so it works without paid AI APIs, and stores progress in PostgreSQL with a browser fallback. Our next step is to validate the role profiles with educators and employers, then add consent-based cohort insights. The goal is simple: help each learner see a next step that fits their own starting point.</p><span className="pitch-time-pill">~2 minutes · speak naturally</span></article><article className="panel demo-script-card"><span className="presentation-label">02 · THREE-MINUTE LIVE DEMO</span><h4>Show the complete learner journey.</h4><ol className="demo-script"><li><span>0:00</span><p><strong>Start on Overview.</strong> Introduce the goal: a personal skill gap view, not another generic course list.</p></li><li><span>0:25</span><p><strong>Open Skill assessment.</strong> Point out the current level, target, gap, and plain-language scoring formula.</p></li><li><span>0:55</span><p><strong>Change one slider.</strong> Watch readiness and top priorities recompute from the updated self-rating.</p></li><li><span>1:25</span><p><strong>Choose a different career.</strong> Show how requirements and gaps adapt to a new goal.</p></li><li><span>1:55</span><p><strong>Open the roadmap and a free course.</strong> Explain the course → project pairing and complete one item.</p></li><li><span>2:35</span><p><strong>Show Progress and About.</strong> Confirm the activity is saved and explain sources, impact, and honest limits.</p></li></ol></article></div>
        <div className="presentation-grid presentation-grid-bottom"><section className="panel tech-card"><span className="presentation-label">03 · STACK + ARCHITECTURE</span><h4>Small, transparent, shippable.</h4><div className="stack-chips"><span>Next.js App Router</span><span>React + TypeScript</span><span>Tailwind CSS v4</span><span>PostgreSQL</span><span>Drizzle ORM</span><span>Rule-based engine</span></div><div className="architecture-flow"><span>Profile + skill sliders</span><i>→</i><span>Career requirements</span><i>→</i><span>Gap score + roadmap</span><i>→</i><span>Drizzle / local fallback</span></div><p>UI actions run in a React client component. A shared TypeScript engine calculates coverage and recommendations. A validated Next.js route stores the learner’s profile in PostgreSQL using Drizzle; localStorage keeps the demo usable if the database is offline.</p></section><section className="panel formula-guide"><span className="presentation-label">04 · EXPLAIN THE CALCULATION</span><h4>Clear enough to do by hand.</h4><div className="formula-large">Coverage = average <span>MIN(current ÷ target, 1)</span> × 100</div><p>Example for AI Engineer: Python 2/5 = 40%; mathematics 3/4 = 75%; Machine Learning 1/5 = 20%; SQL 2/3 ≈ 67%; Data Structures 2/4 = 50%. The average is about <strong>50%</strong> coverage, so the overall gap is about <strong>50%</strong>. Extra levels above a target do not raise the score further.</p><small>Rounded in the interface. This is a skills snapshot, not a validated hiring model.</small></section></div>
        <section className="panel faq-panel"><div className="panel-heading"><div><p className="eyebrow">JUDGES MAY ASK</p><h3>Short, honest answers</h3></div></div><div className="faq-list"><details><summary>Is this powered by a generative AI model?<span>+</span></summary><p>No. This MVP uses a rule-based recommendation engine: select a career, compare self-rated skills to target levels, prioritize the largest gaps, and attach a free resource and project. That keeps the demo explainable and avoids paid API dependencies. An optional AI layer could later draft coaching explanations, with source citations and human review.</p></details><details><summary>How did you choose each skill target?<span>+</span></summary><p>The numbers are clearly labeled example proficiency targets for a hackathon prototype, not an authoritative job standard. The next product step is co-designing role profiles with university faculty and employers, citing those sources, and periodically reviewing them.</p></details><details><summary>How do you know a student actually learned something?<span>+</span></summary><p>This version tracks completed activities and asks the learner to reassess. It does not infer mastery from a video click or silently add skill points. Future versions could include short project rubrics, optional quizzes, and instructor feedback.</p></details><details><summary>How would this help universities without ranking students?<span>+</span></summary><p>With informed consent, role-specific assessments could be aggregated to identify cohort-level training needs. Individual results should stay private to the learner and authorized support staff; the score should guide support, not make admissions or hiring decisions.</p></details></div></section>
        <section className="future-panel"><div><span className="eyebrow">FUTURE SCOPE</span><h3>Make the roadmap smarter — and safer.</h3><p>Validate skills with faculty and employers; add project rubrics and practical assessments; offer multilingual accessibility; integrate approved campus learning catalogs; add opt-in cohort analytics with privacy protections; and test any AI coaching against trusted sources before releasing it.</p></div><div className="future-icons"><span><Icon name="shield" size={18} /></span><span><Icon name="layers" size={18} /></span><span><Icon name="spark" size={18} /></span></div></section>
        <section className="panel eight-hour-panel"><div className="panel-heading"><div><p className="eyebrow">FROM IDEA TO DEMO</p><h3>Eight-hour build plan</h3></div><span className="step-count">8 HOURS</span></div><div className="hour-plan-grid">{[
          ["01", "Scope + setup", "Agree on one learner journey, career targets, and starter assessment."],
          ["02", "Visual foundation", "Build the responsive shell, navigation, and dashboard cards."],
          ["03", "Profile + assessment", "Add career selection and validated skill-level inputs."],
          ["04", "Gap calculation", "Implement and test the visible coverage and readiness formula."],
          ["05", "Roadmap + resources", "Connect gaps to free courses and portfolio projects."],
          ["06", "Dashboard + tracking", "Add progress states and persistent profile saving."],
          ["07", "Test the whole flow", "Exercise navigation, sliders, form validation, and mobile layout."],
          ["08", "Polish + rehearse", "Review sources, prepare the pitch, and run the three-minute demo."],
        ].map(([number, title, detail]) => <article className="hour-plan-item" key={number}><span>{number}</span><div><strong>{title}</strong><p>{detail}</p></div></article>)}</div></section>
      </section>
      <footer className="source-footer"><span>Sources are linked above and checked in the build notes. Market data reflects each report’s publication and scope.</span><button type="button" className="text-link" onClick={() => navigate("overview")}>Back to dashboard <Icon name="arrow" size={14} /></button></footer>
    </>
  );

  return (
    <div className="skillbridge-app">
      {mobileOpen && <button type="button" aria-label="Close navigation" className="mobile-scrim" onClick={() => setMobileOpen(false)} />}
      <aside className={`app-sidebar ${mobileOpen ? "app-sidebar-open" : ""}`} aria-label="Main navigation">
        <button type="button" className="brand-lockup" onClick={() => navigate("overview")} aria-label="SkillBridge AI home"><span className="brand-symbol"><Icon name="spark" size={19} /></span><span>skillbridge<span className="brand-ai">AI</span><small>LEARN WITH DIRECTION</small></span></button>
        <div className="workspace-switcher"><span className="workspace-avatar">A</span><span className="workspace-copy"><strong>Student workspace</strong><small>Demo mode</small></span><span className="workspace-chevron"><Icon name="chevron" size={14} /></span></div>
        <span className="nav-section-label">YOUR LEARNING</span>
        <nav className="side-nav">{NAV.map((item) => <button type="button" key={item.id} onClick={() => navigate(item.id)} className={`side-nav-item ${view === item.id ? "side-nav-active" : ""}`} aria-current={view === item.id ? "page" : undefined}><Icon name={item.icon} size={18} /><span>{item.label}</span>{item.id === "roadmap" && analysis.missing.length > 0 && <i className="nav-count">{analysis.missing.length}</i>}</button>)}</nav>
        <span className="nav-section-label nav-section-secondary">EXPLORE</span>
        <nav className="side-nav"><button type="button" onClick={() => navigate("profile")} className={`side-nav-item ${view === "profile" ? "side-nav-active" : ""}`} aria-current={view === "profile" ? "page" : undefined}><Icon name="user" size={18} /><span>My profile</span></button><button type="button" onClick={() => navigate("about")} className={`side-nav-item ${view === "about" ? "side-nav-active" : ""}`} aria-current={view === "about" ? "page" : undefined}><Icon name="layers" size={18} /><span>About the project</span></button></nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-nudge"><div className="nudge-icon"><Icon name="spark" size={18} /></div><strong>Your next step is waiting.</strong><p>A little progress adds up. Pick one skill and begin.</p><button type="button" onClick={() => navigate("roadmap")}>Open roadmap <Icon name="arrow" size={14} /></button><span className="nudge-decoration" /></div>
        <button type="button" className="sidebar-user" onClick={() => navigate("profile")}><span className="user-avatar">{getInitials(profile.name)}</span><span className="user-copy"><strong>{profile.name}</strong><small>{currentCareer.title}</small></span><Icon name="settings" size={16} /></button>
      </aside>

      <main className="app-main">
        <header className="app-topbar"><div className="topbar-title-wrap"><button type="button" className="mobile-menu-button" aria-label="Open navigation" aria-expanded={mobileOpen} onClick={() => setMobileOpen(true)}><Icon name="menu" size={20} /></button><div><span className="topbar-kicker">SKILLBRIDGE AI <i>·</i> DEMO WORKSPACE</span><h1>{VIEW_TITLES[view]}</h1></div></div><div className="topbar-actions"><div className={`save-status save-status-${saveState}`} aria-live="polite"><i />{saveState === "loading" ? "Loading" : saveState === "saving" ? "Saving" : saveState === "saved" ? "All changes saved" : "Browser save"}</div><button type="button" className="topbar-icon-button" aria-label="Download your career plan" onClick={exportPlan}><Icon name="download" size={17} /></button><button type="button" className="topbar-profile" onClick={() => navigate("profile")}><span className="topbar-avatar">{getInitials(profile.name)}</span><span>{profile.name.split(" ")[0]}</span><Icon name="chevron" size={14} /></button></div></header>
        <div className="app-content">
          {view === "overview" && renderOverview()}
          {view === "assessment" && renderAssessment()}
          {view === "roadmap" && renderRoadmap()}
          {view === "courses" && renderCourses()}
          {view === "progress" && renderProgress()}
          {view === "profile" && renderProfile()}
          {view === "about" && renderAbout()}
          <footer className="app-footer"><span>SkillBridge AI <i>·</i> Learn with direction.</span><span>{saveState === "saved" ? "Progress saved securely to the demo workspace" : saveState === "local" ? "Progress is saved in this browser" : "Recommendations are rule-based and explainable"}</span><span className="footer-links"><button type="button" onClick={() => navigate("about")}>Project notes</button><span>·</span><button type="button" onClick={() => navigate("profile")}>Demo profile</button></span></footer>
        </div>
      </main>
      {toast && <div className="toast-message" role="status"><span className="toast-check"><Icon name="check" size={15} /></span>{toast}</div>}
    </div>
  );
}
