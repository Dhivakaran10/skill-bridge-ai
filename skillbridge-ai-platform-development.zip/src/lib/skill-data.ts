export type SkillId =
  | "python"
  | "mathematics"
  | "machineLearning"
  | "sql"
  | "dataStructures"
  | "statistics"
  | "dataVisualization"
  | "html"
  | "css"
  | "javascript"
  | "react"
  | "networking"
  | "linux"
  | "cybersecurity"
  | "problemSolving"
  | "communication";

export type Skill = {
  id: SkillId;
  name: string;
  group: string;
  icon: string;
  description: string;
};

export const SKILLS: Skill[] = [
  { id: "python", name: "Python", group: "Programming", icon: "Py", description: "Write clear programs, work with data, and use core language tools." },
  { id: "mathematics", name: "Mathematics", group: "Foundations", icon: "∑", description: "Build the linear algebra and calculus intuition used in machine learning." },
  { id: "machineLearning", name: "Machine learning", group: "AI & data", icon: "ML", description: "Train, evaluate, and explain predictive models." },
  { id: "sql", name: "SQL", group: "Data", icon: "SQ", description: "Query, join, and prepare structured data." },
  { id: "dataStructures", name: "Data structures", group: "Computer science", icon: "DS", description: "Choose useful structures and reason about algorithmic trade-offs." },
  { id: "statistics", name: "Statistics", group: "Foundations", icon: "σ", description: "Reason about distributions, uncertainty, and experiments." },
  { id: "dataVisualization", name: "Data visualization", group: "Data", icon: "DV", description: "Turn analysis into clear charts and useful narratives." },
  { id: "html", name: "HTML", group: "Web", icon: "<>" , description: "Structure accessible pages with semantic markup." },
  { id: "css", name: "CSS", group: "Web", icon: "#", description: "Build responsive layouts and polished interfaces." },
  { id: "javascript", name: "JavaScript", group: "Programming", icon: "JS", description: "Add interactivity and understand the browser runtime." },
  { id: "react", name: "React", group: "Web", icon: "⚛", description: "Compose interfaces from reusable components and state." },
  { id: "networking", name: "Networking", group: "Security", icon: "NW", description: "Understand network layers, protocols, and traffic." },
  { id: "linux", name: "Linux", group: "Security", icon: "LX", description: "Use the command line, permissions, and system tools." },
  { id: "cybersecurity", name: "Cybersecurity", group: "Security", icon: "SH", description: "Apply security fundamentals and responsible threat analysis." },
  { id: "problemSolving", name: "Problem solving", group: "Professional", icon: "✳", description: "Break ambiguous problems into testable steps." },
  { id: "communication", name: "Communication", group: "Professional", icon: "↗", description: "Explain technical work to teammates and stakeholders." },
];

export const CAREERS = [
  {
    id: "ai-engineer",
    title: "AI Engineer",
    category: "Artificial intelligence",
    icon: "✳",
    color: "violet",
    summary: "Build intelligent products by bringing data, models, and software together.",
    requirements: { python: 5, mathematics: 4, machineLearning: 5, sql: 3, dataStructures: 4 },
  },
  {
    id: "data-scientist",
    title: "Data Scientist",
    category: "Data & analytics",
    icon: "◉",
    color: "blue",
    summary: "Find useful patterns in data and turn them into evidence-backed decisions.",
    requirements: { python: 4, statistics: 5, machineLearning: 4, sql: 4, dataVisualization: 4 },
  },
  {
    id: "web-developer",
    title: "Web Developer",
    category: "Software & web",
    icon: "⌘",
    color: "orange",
    summary: "Create fast, accessible websites and interactive web experiences.",
    requirements: { html: 5, css: 5, javascript: 5, react: 4, problemSolving: 3 },
  },
  {
    id: "cybersecurity-analyst",
    title: "Cybersecurity Analyst",
    category: "Security",
    icon: "⛨",
    color: "green",
    summary: "Help protect systems by understanding networks, threats, and defenses.",
    requirements: { networking: 4, linux: 4, cybersecurity: 5, python: 3, problemSolving: 4 },
  },
  {
    id: "software-engineer",
    title: "Software Engineer",
    category: "Software & web",
    icon: "⌘",
    color: "pink",
    summary: "Design, build, test, and maintain reliable software products.",
    requirements: { dataStructures: 5, python: 4, sql: 3, problemSolving: 4, communication: 3 },
  },
] as const;

export type CareerId = (typeof CAREERS)[number]["id"];
export type Career = (typeof CAREERS)[number];

export type Course = {
  id: string;
  skillId: SkillId;
  title: string;
  provider: string;
  detail: string;
  href: string;
  duration: string;
  format: string;
};

export const COURSES: Course[] = [
  { id: "py4e", skillId: "python", title: "Python for Everybody", provider: "University of Michigan", detail: "Free lessons and exercises for programming foundations.", href: "https://www.py4e.com/lessons", duration: "Self-paced", format: "Course" },
  { id: "kaggle-python", skillId: "python", title: "Python", provider: "Kaggle Learn", detail: "Short, hands-on lessons in notebooks.", href: "https://www.kaggle.com/learn/python", duration: "5 lessons", format: "Interactive" },
  { id: "khan-linear", skillId: "mathematics", title: "Linear algebra", provider: "Khan Academy", detail: "Build intuition for vectors, matrices, and transformations.", href: "https://www.khanacademy.org/math/linear-algebra", duration: "Self-paced", format: "Course" },
  { id: "khan-calculus", skillId: "mathematics", title: "Differential calculus", provider: "Khan Academy", detail: "Review derivatives and the ideas behind optimization.", href: "https://www.khanacademy.org/math/differential-calculus", duration: "Self-paced", format: "Course" },
  { id: "google-ml", skillId: "machineLearning", title: "Machine Learning Crash Course", provider: "Google for Developers", detail: "A practical introduction with visualizations and exercises.", href: "https://developers.google.com/machine-learning/crash-course", duration: "15+ hours", format: "Course" },
  { id: "kaggle-ml", skillId: "machineLearning", title: "Intro to Machine Learning", provider: "Kaggle Learn", detail: "Learn model validation and a first decision tree.", href: "https://www.kaggle.com/learn/intro-to-machine-learning", duration: "3 hours", format: "Interactive" },
  { id: "sqlbolt", skillId: "sql", title: "SQLBolt", provider: "SQLBolt", detail: "Practice queries, joins, and table design in the browser.", href: "https://sqlbolt.com/", duration: "18 lessons", format: "Interactive" },
  { id: "kaggle-sql", skillId: "sql", title: "Intro to SQL", provider: "Kaggle Learn", detail: "Query real datasets with short guided exercises.", href: "https://www.kaggle.com/learn/intro-to-sql", duration: "5 lessons", format: "Interactive" },
  { id: "visu-ds", skillId: "dataStructures", title: "Data structure visualizations", provider: "VisuAlgo", detail: "Explore how common structures and algorithms behave.", href: "https://visualgo.net/en", duration: "Self-paced", format: "Visual guide" },
  { id: "cs50x", skillId: "dataStructures", title: "CS50x: Introduction to Computer Science", provider: "Harvard University", detail: "Free lectures and problem sets in computer science.", href: "https://cs50.harvard.edu/x/", duration: "Self-paced", format: "Course" },
  { id: "khan-stats", skillId: "statistics", title: "Statistics and probability", provider: "Khan Academy", detail: "Learn distributions, inference, and probability basics.", href: "https://www.khanacademy.org/math/statistics-probability", duration: "Self-paced", format: "Course" },
  { id: "kaggle-viz", skillId: "dataVisualization", title: "Data Visualization", provider: "Kaggle Learn", detail: "Practice chart choice and visual storytelling with data.", href: "https://www.kaggle.com/learn/data-visualization", duration: "4 lessons", format: "Interactive" },
  { id: "mdn-html", skillId: "html", title: "Learn HTML", provider: "MDN Web Docs", detail: "Build a strong foundation in semantic HTML.", href: "https://developer.mozilla.org/en-US/docs/Learn/HTML", duration: "Self-paced", format: "Guided guide" },
  { id: "mdn-css", skillId: "css", title: "Learn CSS", provider: "MDN Web Docs", detail: "Practice styling, layout, and responsive design.", href: "https://developer.mozilla.org/en-US/docs/Learn/CSS", duration: "Self-paced", format: "Guided guide" },
  { id: "mdn-js", skillId: "javascript", title: "JavaScript Guide", provider: "MDN Web Docs", detail: "Understand language basics, functions, and objects.", href: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide", duration: "Self-paced", format: "Guide" },
  { id: "react-learn", skillId: "react", title: "Learn React", provider: "React", detail: "Follow the official interactive React tutorial.", href: "https://react.dev/learn", duration: "Self-paced", format: "Interactive" },
  { id: "cisco-net", skillId: "networking", title: "Networking Basics", provider: "Cisco Skills for All", detail: "Learn the fundamentals of network communication.", href: "https://skillsforall.com/course/networking-basics", duration: "Self-paced", format: "Course" },
  { id: "linux-journey", skillId: "linux", title: "Linux Journey", provider: "Linux Journey", detail: "A beginner-friendly path through the Linux command line.", href: "https://linuxjourney.com/", duration: "Self-paced", format: "Guided guide" },
  { id: "cisco-cyber", skillId: "cybersecurity", title: "Introduction to Cybersecurity", provider: "Cisco Skills for All", detail: "Explore security concepts, threats, and career paths.", href: "https://skillsforall.com/course/introduction-to-cybersecurity", duration: "Self-paced", format: "Course" },
  { id: "cs50-problem", skillId: "problemSolving", title: "CS50x: Problem sets", provider: "Harvard University", detail: "Practice breaking programming problems into steps.", href: "https://cs50.harvard.edu/x/", duration: "Self-paced", format: "Practice" },
  { id: "communication-guide", skillId: "communication", title: "Technical writing courses", provider: "Google for Developers", detail: "Learn clear, useful documentation for technical work.", href: "https://developers.google.com/tech-writing", duration: "Self-paced", format: "Course" },
];

export type Project = {
  skillId: SkillId;
  title: string;
  detail: string;
  outcome: string;
};

export const PROJECTS: Record<SkillId, Project> = {
  python: { skillId: "python", title: "Build a study-time tracker", detail: "Write a small Python app that records sessions, validates input, and summarizes weekly totals.", outcome: "A runnable script with a README and sample output." },
  mathematics: { skillId: "mathematics", title: "Visualize a vector transformation", detail: "Use a few vectors and a 2×2 matrix to plot how a transformation changes points.", outcome: "A notebook with annotated plots and a plain-English explanation." },
  machineLearning: { skillId: "machineLearning", title: "Train a transparent classifier", detail: "Use a public dataset, make a baseline, split your data, and compare two simple models.", outcome: "A notebook documenting the metric, limits, and model choice." },
  sql: { skillId: "sql", title: "Explore a public dataset", detail: "Write five queries that filter, aggregate, and join a small dataset.", outcome: "A SQL file with questions, queries, and readable results." },
  dataStructures: { skillId: "dataStructures", title: "Build a searchable mini-library", detail: "Store a small collection, add a search feature, and compare a list scan with a map lookup.", outcome: "A demo plus a short note about time complexity." },
  statistics: { skillId: "statistics", title: "Run a tiny A/B analysis", detail: "Create or find a small dataset and explain its distribution, uncertainty, and limitations.", outcome: "A notebook with one chart and a careful conclusion." },
  dataVisualization: { skillId: "dataVisualization", title: "Tell a story with three charts", detail: "Choose a public dataset and build three charts that answer one clear question.", outcome: "A shareable dashboard with a short insight summary." },
  html: { skillId: "html", title: "Create an accessible profile page", detail: "Use semantic page landmarks, a clear heading order, and meaningful links.", outcome: "A responsive page that works without a mouse." },
  css: { skillId: "css", title: "Design a responsive card grid", detail: "Build a flexible card layout that adapts from a small screen to desktop.", outcome: "A live page with documented breakpoints." },
  javascript: { skillId: "javascript", title: "Make a useful form interactive", detail: "Validate a small form and show helpful success and error states.", outcome: "A working browser demo with input edge cases tested." },
  react: { skillId: "react", title: "Build a component-based task board", detail: "Create reusable cards and make add, filter, and complete interactions work.", outcome: "A small React app with state and a short setup guide." },
  networking: { skillId: "networking", title: "Map a sample network", detail: "Diagram a small home or campus network and label devices, routes, and protocols.", outcome: "A clearly labeled diagram and a one-page explanation." },
  linux: { skillId: "linux", title: "Create a command-line toolkit", detail: "Write a short shell script that organizes sample files and logs its actions.", outcome: "A tested script with safe input handling." },
  cybersecurity: { skillId: "cybersecurity", title: "Write a safe threat model", detail: "Choose a fictional app, list assets and risks, then propose defensive controls.", outcome: "A threat-model worksheet; no real systems are tested." },
  problemSolving: { skillId: "problemSolving", title: "Explain a problem before coding", detail: "Choose a small problem, list examples and edge cases, then compare two approaches.", outcome: "A short solution note with tests and trade-offs." },
  communication: { skillId: "communication", title: "Publish a project walkthrough", detail: "Explain a project goal, design choice, result, and next step for a non-specialist.", outcome: "A concise README or 3-minute screen recording." },
};

export type SkillGap = Skill & { current: number; target: number; gap: number; coverage: number };

export function getCareer(careerId: string): Career {
  return CAREERS.find((career) => career.id === careerId) ?? CAREERS[0];
}

export function getSkill(skillId: SkillId): Skill {
  return SKILLS.find((skill) => skill.id === skillId) ?? SKILLS[0];
}

export function analyzeCareer(careerId: string, levels: Partial<Record<SkillId, number>>) {
  const career = getCareer(careerId);
  const rows = Object.entries(career.requirements).map(([id, target]) => {
    const skillId = id as SkillId;
    const skill = getSkill(skillId);
    const current = Math.min(5, Math.max(0, Math.round(levels[skillId] ?? 0)));
    const capped = Math.min(current, target);
    return { ...skill, current, target, gap: Math.max(0, target - current), coverage: Math.round((capped / target) * 100) };
  });
  const score = rows.length ? Math.round(rows.reduce((sum, row) => sum + row.coverage, 0) / rows.length) : 0;
  const totalLevels = rows.reduce((sum, row) => sum + row.target, 0);
  const earnedLevels = rows.reduce((sum, row) => sum + Math.min(row.current, row.target), 0);
  const weightedCoverage = totalLevels ? Math.round((earnedLevels / totalLevels) * 100) : 0;
  return {
    career,
    rows,
    score,
    coverage: score,
    gapPercent: 100 - score,
    weightedCoverage,
    missing: rows.filter((row) => row.gap > 0).sort((a, b) => b.gap / b.target - a.gap / a.target),
  };
}

export function courseActivityId(courseId: string) {
  return `course:${courseId}`;
}

export function projectActivityId(skillId: SkillId) {
  return `project:${skillId}`;
}

export function getCoursesForCareer(careerId: string, levels: Partial<Record<SkillId, number>>, completed: string[] = []) {
  const analysis = analyzeCareer(careerId, levels);
  const priority = new Map(analysis.missing.map((row, index) => [row.id, index]));
  return COURSES
    .filter((course) => priority.has(course.skillId) && !completed.includes(courseActivityId(course.id)))
    .sort((a, b) => (priority.get(a.skillId) ?? 99) - (priority.get(b.skillId) ?? 99))
    .slice(0, 8);
}

export type RoadmapActivity = {
  id: string;
  kind: "course" | "project";
  skillId: SkillId;
  title: string;
  detail: string;
  duration: string;
  href?: string;
  provider?: string;
  complete: boolean;
};

export function getRoadmap(careerId: string, levels: Partial<Record<SkillId, number>>, completed: string[] = []): RoadmapActivity[] {
  const { missing } = analyzeCareer(careerId, levels);
  return missing.flatMap((row) => {
    const course = COURSES.find((entry) => entry.skillId === row.id);
    const project = PROJECTS[row.id];
    const items: RoadmapActivity[] = [];
    if (course) {
      const id = courseActivityId(course.id);
      items.push({ id, kind: "course", skillId: row.id, title: course.title, detail: course.detail, duration: course.duration, href: course.href, provider: course.provider, complete: completed.includes(id) });
    }
    const projectId = projectActivityId(row.id);
    items.push({ id: projectId, kind: "project", skillId: row.id, title: project.title, detail: project.detail, duration: "Portfolio project", complete: completed.includes(projectId) });
    return items;
  });
}

export const DEFAULT_PROFILE = {
  id: "demo-learner",
  name: "Alex Morgan",
  email: "alex.morgan@example.com",
  career: "ai-engineer" as CareerId,
  skills: {
    python: 2,
    mathematics: 3,
    machineLearning: 1,
    sql: 2,
    dataStructures: 2,
    statistics: 1,
    dataVisualization: 1,
    html: 2,
    css: 2,
    javascript: 2,
    react: 1,
    networking: 1,
    linux: 1,
    cybersecurity: 1,
    problemSolving: 3,
    communication: 3,
  } satisfies Record<SkillId, number>,
  completed: [] as string[],
};

export type LearnerProfile = typeof DEFAULT_PROFILE;

export const MARKET_SOURCES = [
  {
    publisher: "World Economic Forum",
    title: "The Future of Jobs Report 2025",
    date: "7 Jan 2025",
    finding: "39% of workers’ existing skills are expected to change or become outdated by 2030; 63% of surveyed employers cite skill gaps as a major transformation barrier.",
    href: "https://www.weforum.org/publications/the-future-of-jobs-report-2025/",
  },
  {
    publisher: "ILO & Institute for Human Development",
    title: "India Employment Report 2024: Youth employment, education and skills",
    date: "29 Mar 2024",
    finding: "In 2022, youth unemployment was 18.4% among those with secondary or higher education and 29.1% among graduates; the report analyzes how education and skills intersect with youth employment.",
    href: "https://www.ilo.org/publications/india-employment-report-2024-youth-employment-education-and-skills",
  },
  {
    publisher: "India Skills Report / Wheebox",
    title: "India Skills Report 2025",
    date: "Dec 2024",
    finding: "The report estimates 54.81% graduate employability for 2025, based on its Global Employability Test and employer inputs; this is an employability estimate, not an unemployment rate.",
    href: "https://wheebox.com/assets/pdf/ISR_Report_2025.pdf",
  },
];
